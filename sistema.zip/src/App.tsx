import { Routing } from './router/Routing'

function App (): JSX.Element {
  return (
    <>
     <Routing/>
    </>
  )
}
export default App
