
export const WebSocketNotifications = (): JSX.Element => {
  return (
    <></>
  )
}
