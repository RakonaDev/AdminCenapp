/*
export const Global = {
  url: 'https://api.navesport.com/api',
  urlImages: 'https://api.navesport.com/api'
}
*/
export const Global = {
  url: 'http://localhost:4000/api',
  urlImages: 'http://localhost:4000'
}

// // export const Global = {
// //   url: 'http://apinavesport.logosperu.com.pe/api',
// //   urlImages: 'http://apinavesport.logosperu.com.pe/api'
// // }
