const id: string = ''
const nombres: string = ''
const apellidos: string = ''
const email: string = ''
const rolId: number | null = null

export const UserSchema = {
  id,
  nombres,
  apellidos,
  email,
  rolId
}
